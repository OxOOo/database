#include "Jaccard.h"

using namespace std;

Jaccard::Jaccard()
{
}

Jaccard::~Jaccard()
{
}

int Jaccard::init(const char* filename, unsigned q)
{
    return SUCCESS;
}

int Jaccard::search(const string query, double threshold, vector<pair<unsigned, double> > &result)
{
    result.clear();
    return SUCCESS;
}
